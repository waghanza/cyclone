# coding: utf-8

import ConfigParser
from twisted.python import usage
from twisted.plugin import IPlugin
from twisted.application import service, internet
from zope.interface import implements

import $modname.web
import $modname.config

class Options(usage.Options):
    optParameters = [
        ["config", "c", "$modname.conf", "set configuration file"],
    ]

class ServiceMaker(object):
    implements(service.IServiceMaker, IPlugin)
    tapname = "$modname"
    description = "cyclone-based web server"
    options = Options

    def makeService(self, options):
        port, listen, settings = $modname.config.parse_config(options["config"])
        return internet.TCPServer(port,
            $modname.web.Application(settings),
            interface=listen)

serviceMaker = ServiceMaker()
