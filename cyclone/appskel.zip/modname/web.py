# coding: utf-8

import cyclone.locale
import cyclone.redis
import cyclone.sqlite
import cyclone.web

from $modname import views

class Application(cyclone.web.Application):
    def __init__(self, settings):
        mysqldb = mysql_connection(settings.get("mysql_settings"))
        redisdb = redis_connection(settings.get("redis_settings"))
        sqlitedb = sqlite_connection(settings.get("sqlite_settings"))

        handlers = [
            (r"/",          views.IndexHandler),
            (r"/lang/(.+)", views.LangHandler),
            (r"/s/mysql",   views.SampleMySQLHandler,  dict(mysqldb=mysqldb)),
            (r"/s/redis",   views.SampleRedisHandler,  dict(redisdb=redisdb)),
            (r"/s/sqlite",  views.SampleSQLiteHandler, dict(sqlitedb=sqlitedb)),
        ]

        locales = settings.get("locale_path")
        if locales:
            cyclone.locale.load_gettext_translations(locales, "$modname")

        #settings["login_url"] = "/auth/login"
        cyclone.web.Application.__init__(self, handlers, **settings)


def mysql_connection(conf):
    if conf:
        return adbapi.ConnectionPool("MySQLdb",
                            host=conf.host, port=conf.port, db=conf.database,
                            user=conf.username, passwd=conf.password,
                            cp_min=1, cp_max=conf.poolsize,
                            cp_reconnect=True, cp_noisy=conf.debug)

def redis_connection(conf):
    if conf:
        return cyclone.redis.lazyRedisConnectionPool(
                            host=conf.host, port=conf.port,
                            db=conf.dbid, pool_size=conf.poolsize)

def sqlite_connection(conf):
    if conf:
        return cyclone.sqlite.InlineSQLite(conf.database)
