# coding: utf-8

import cyclone.web

from $modname import views

class Application(cyclone.web.Application):
    def __init__(self, settings):
        handlers = [
            (r"/",              views.MainHandler),
            (r"/lang/(.+)",     views.LangHandler),
            (r"/auth/login",    views.AuthLoginHandler),
            (r"/auth/logout",   views.AuthLogoutHandler),
            (r"/sample/mysql",  views.SampleMysqlHandler),
            (r"/sample/redis",  views.SampleRedisHandler),
        ]

        settings["login_url"] = "/auth/login"
        settings["xsrf_cookies"] = False
        cyclone.locale.load_translations(settings["locale_path"], "$modname")
        cyclone.web.Application.__init__(self, handlers, **settings)
