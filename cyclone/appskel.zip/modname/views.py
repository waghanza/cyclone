# coding: utf-8

import cyclone.escape
import cyclone.locale
import cyclone.web

from twisted.internet import defer
from twisted.python import log


class BaseHandler(cyclone.web.RequestHandler):
    def get_current_user(self):
        user_json = self.get_secure_cookie("user")
        if user_json:
            return cyclone.escape.json_decode(user_json)

    def get_user_locale(self):
        lang = self.get_secure_cookie("lang")
        if lang:
            return cyclone.locale.get(lang)


class IndexHandler(BaseHandler):
    def get(self):
        self.render("index.html")


class LangHandler(BaseHandler):
    def get(self, lang_code):
        if lang_code in cyclone.locale.get_supported_locales():
            self.set_secure_cookie("lang", lang_code)

        n = self.request.headers.get("Referer", self.get_argument("next", "/"))
        self.redirect(n)


class SampleSQLiteHandler(BaseHandler):
    def initialize(self, sqlitedb):
        self.sqlitedb = sqlitedb

    def get(self):
        if self.sqlitedb:
            response = self.sqlitedb.runQuery("select strftime('%Y-%m-%d')")
            self.write({"response":response})
        else:
            self.write("SQLite is disabled\r\n")


class SampleRedisHandler(BaseHandler):
    def initialize(self, redisdb):
        self.redisdb = redisdb

    @defer.inlineCallbacks
    def get(self):
        if self.redisdb:
            try:
                response = yield self.redisdb.get("foo")
            except Exception, e:
                log.msg("Redis query failed: %s" % str(e))
                raise cyclone.web.HTTPError(503) # Service Unavailable
            else:
                self.write({"response":response})
        else:
            self.write("Redis is disabled\r\n")


class SampleMySQLHandler(BaseHandler):
    def initialize(self, mysqldb):
        self.mysqldb = mysqldb

    @defer.inlineCallbacks
    def get(self):
        if self.mysqldb:
            try:
                query = "select now()"
                response = yield self.mysqldb.runQuery("select now()")
            except Exception, e:
                log.msg("MySQL query failed: %s" % str(e))
                raise cyclone.web.HTTPError(503) # Service Unavailable
            else:
                self.write({"response":response})
        else:
            self.write("MySQL is disabled\r\n")

