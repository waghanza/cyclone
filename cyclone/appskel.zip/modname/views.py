# coding: utf-8

import cyclone.escape
import cyclone.locale
import cyclone.web
from twisted.python import log
from twisted.internet import defer

class BaseHandler(cyclone.web.RequestHandler):
    def get_current_user(self):
        user_json = self.get_secure_cookie("user")
        if user_json:
            return cyclone.escape.json_decode(user_json)

    def get_user_locale(self):
        lang = self.get_secure_cookie("lang")
        if lang:
            return cyclone.locale.get(lang)

class MainHandler(BaseHandler):
    def get(self):
        self.render("index.html")

class LangHandler(BaseHandler):
    def get(self, lang_code):
        if lang_code in cyclone.locale.get_supported_locales():
            self.set_secure_cookie("lang", lang_code)
        #else:
        #    raise cyclone.web.HTTPError(404)

        self.redirect(self.get_argument("next", "/"))

class AuthLoginHandler(BaseHandler):
    pass

class AuthLogoutHandler(BaseHandler):
    pass

class SampleSQLiteHandler(BaseHandler):
    def get(self):
        if "_sqlite" in self.settings:
            try:
                query = "select strftime('%Y-%m-%d')"
                rs = self.settings._sqlite.runQuery(query)
                self.write("%s = %s" % (query, repr(rs)))
            except Exception, e:
                self.log("sqlite query failed: %s" % e)
                raise cyclone.web.HTTPError(503)
        else:
            self.write("sqlite is disabled")

class SampleMySQLHandler(BaseHandler):
    @defer.inlineCallbacks
    def get(self):
        if "_mysql" in self.settings:
            try:
                query = "select now()"
                rs = yield self.settings._mysql.runQuery(query)
                self.write("%s = %s" % (query, repr(rs)))
            except Exception, e:
                self.log("mysql query failed: %s" % e)
                raise cyclone.web.HTTPError(503)
        else:
            self.write("mysql is disabled")

class SampleRedisHandler(BaseHandler):
    @defer.inlineCallbacks
    def get(self):
        if "_redis" in self.settings:
            try:
                rs = yield self.settings._redis.get("foo")
                self.write("k=foo, v=%s" % rs)
            except Exception, e:
                self.log("redis query failed: %s" % e)
                raise cyclone.web.HTTPError(503)
        else:
            self.write("redis is disabled")
