# coding: utf-8

import cyclone.escape
import cyclone.locale
import cyclone.web
from twisted.python import log
from twisted.internet import defer

class BaseHandler(cyclone.web.RequestHandler):
    def get_current_user(self):
        user_json = self.get_secure_cookie("user")
        if user_json:
            return cyclone.escape.json_decode(user_json)

    def get_user_locale(self):
        lang = self.get_secure_cookie("lang")
        if lang:
            return cyclone.locale.get(lang)

class MainHandler(BaseHandler):
    def get(self):
        self.render("index.html")

class LangHandler(BaseHandler):
    def get(self, lang_code):
        if lang_code in cyclone.locale.get_supported_locales():
            self.set_secure_cookie("lang", lang_code)
        #else:
        #    raise cyclone.web.HTTPError(404)

        self.redirect(self.get_argument("next", "/"))

class AuthLoginHandler(BaseHandler):
    pass

class AuthLogoutHandler(BaseHandler):
    pass

class SampleMysqlHandler(BaseHandler):
    pass

class SampleRedisHandler(BaseHandler):
    pass
