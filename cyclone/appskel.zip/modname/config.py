# coding: utf-8

import ConfigParser
import cyclone.redis
import cyclone.sqlite
import os
from twisted.enterprise import adbapi

def getboolean(cfg, k, v, default=False):
    try:
        return cfg.getboolean(k, v)
    except:
        return default

def parse_config(filename):
    cfg = ConfigParser.RawConfigParser()
    with open(filename) as fp:
        cfg.readfp(fp)

    # port and interface to listen on
    port = cfg.getint("global", "port")
    listen = cfg.get("global", "listen")

    # web server settings
    settings = {}
    settings["cookie_secret"] = cfg.get("global", "cookie_secret")
    settings["xheaders"] = getboolean(cfg, "global", "xheaders")
    settings["debug"] = getboolean(cfg, "global", "debug")

    # get project's absolute path
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    getpath = lambda k, v: os.path.join(root, cfg.get(k, v))

    # locale, template and static directories' path
    settings["locale_path"] = getpath("frontend", "locale_path")
    settings["static_path"] = getpath("frontend", "static_path")
    settings["template_path"] = getpath("frontend", "template_path")

    # sqlite support
    sqlite_enabled = getboolean(cfg, "sqlite", "enabled")
    if sqlite_enabled:
        sqlite_filename = getpath("sqlite", "filename")
        settings["_sqlite"] = cyclone.sqlite.InlineSQLite(sqlite_filename)

    # mysql support
    mysql_enabled = getboolean(cfg, "mysql", "enabled")
    if mysql_enabled:
        mysql_host = cfg.get("mysql", "host")
        mysql_port = cfg.getint("mysql", "port")
        mysql_username = cfg.get("mysql", "username")
        mysql_password = cfg.get("mysql", "password")
        mysql_database = cfg.get("mysql", "database")
        mysql_poolsize = cfg.getint("mysql", "poolsize")
        mysql_debug = cfg.getboolean("mysql", "debug")
        settings["_mysql"] = adbapi.ConnectionPool("MySQLdb",
            host=mysql_host, port=mysql_port, db=mysql_database,
            user=mysql_username, passwd=mysql_password,
            cp_min=mysql_poolsize/2, cp_max=mysql_poolsize,
            cp_reconnect=True, cp_noisy=mysql_debug)

    # redis support
    redis_enabled = getboolean(cfg, "redis", "enabled")
    if redis_enabled:
        redis_host = cfg.get("redis", "host")
        redis_port = cfg.getint("redis", "port")
        redis_dbid = cfg.getint("redis", "dbid")
        redis_poolsize = cfg.getint("redis", "poolsize")
        settings["_redis"] = cyclone.redis.lazyRedisConnectionPool(
            redis_host, redis_port, db=redis_dbid, pool_size=redis_poolsize)

    # it must always return a tuple of (port, listen, settings)
    return (port, listen, settings)
