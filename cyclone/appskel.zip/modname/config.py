# coding: utf-8

import ConfigParser
import cyclone.redis
from twisted.enterprise import adbapi

def parse_config(filename):
    cfg = ConfigParser.RawConfigParser()
    with open(filename) as fp:
        cfg.readfp(fp)

    # port and interface to listen on
    port = cfg.getint("global", "port")
    listen = cfg.get("global", "listen")

    # web server settings
    settings = {}
    settings["xheaders"] = cfg.getboolean("global", "xheaders")
    settings["locale_path"] = cfg.get("frontend", "locale_path")
    settings["static_path"] = cfg.get("frontend", "static_path")
    settings["template_path"] = cfg.get("frontend", "template_path")
    settings["cookie_secret"] = cfg.get("frontend", "cookie_secret")

    # mysql database connection
    mysql_host = cfg.get("mysql", "host")
    mysql_port = cfg.getint("mysql", "port")
    mysql_username = cfg.get("mysql", "username")
    mysql_password = cfg.get("mysql", "password")
    mysql_database = cfg.get("mysql", "database")
    mysql_poolsize = cfg.getint("mysql", "poolsize")
    mysql_debug = cfg.getboolean("mysql", "debug")

    #settings["_mysql"] = adbapi.ConnectionPool("MySQLdb",
    #    host=mysql_host, port=mysql_port, db=mysql_database,
    #    user=mysql_username, passwd=mysql_password,
    #    cp_min=mysql_poolsize/2, cp_max=mysql_poolsize,
    #    cp_reconnect=True, cp_noisy=mysql_debug)

    # redis database connection
    redis_host = cfg.get("redis", "host")
    redis_port = cfg.getint("redis", "port")
    redis_dbid = cfg.getint("redis", "dbid")
    redis_poolsize = cfg.getint("redis", "poolsize")

    #settings["_redis"] = cyclone.redis.lazyRedisConnectionPool(
    #    redis_host, redis_port, db=redis_dbid, pool_size=redis_poolsize)

    # it's mandatory to return a tuple of (port, listen, settings)
    return (port, listen, settings)
